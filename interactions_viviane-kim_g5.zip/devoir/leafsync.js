"use strict";

// Fonction pour basculer l'affichage du menu déroulant
function toggleMenu() {
    const navMenu = document.querySelector('.nav-menu');
    navMenu.classList.toggle('show');
}


// DARKMODE
let interrupteur = 0;

function DarkModeBouton() {
    let body = document.body;
    let DarkMode = document.getElementById('DarkMode');

    if (interrupteur === 0) {
        body.style.background = 'black';
        body.style.color = 'white';
        DarkMode.src = 'images/soleil.png';
        interrupteur = 1;
    } else {
        body.style.background = 'white';
        body.style.color = 'black';
        DarkMode.src = 'images/lune.png';
        interrupteur = 0;
    }
}

let DarkModeButton = document.getElementById('DarkMode');
DarkModeButton.addEventListener("click", DarkModeBouton);